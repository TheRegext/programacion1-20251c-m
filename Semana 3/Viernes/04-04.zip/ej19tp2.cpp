///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;


int main(){
    int horas;
    float costoTotal,valorHora, esUrgente;
    bool urgente;
    char lenguaje;
    cout<<"INGRESAR HORAS ";
    cin>>horas;
    cout<<"INGRESAR LENGUAJE ";
    cin>>lenguaje;
    cout<<"INGRESAR SI ES URGENTE (1: URGENTE; 0: NO URGENTE )";
    cin>>urgente;
    ///fin de los ingresos

    ///operaciones
    switch(lenguaje){
        case 'C':   valorHora=7500;
                    break;
        case '#':   valorHora=6100;
                            break;
        case 'P':   valorHora=5400;
                            break;
        case 'G':   valorHora=5000;
                            break;
        default:    cout<<"ERROR EN EL INGRESO DEL LENGUAJE"<<endl;
                    valorHora=0;
                    break;
    }
    if(urgente==true){///if(urgente) es equivalente
        esUrgente=2.2;
    }
    else{
        esUrgente=1;
    }

    costoTotal=horas*valorHora*esUrgente;

    ///salida
    cout<<"COSTO TOTAL DEL PROYECTO $"<<costoTotal;
	cout<<endl;
	system("pause");
	return 0;
}
