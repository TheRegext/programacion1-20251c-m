///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;


int main(){
    int n1, n2, n3;
    cout<<"INGRESAR NUMERO ";
    cin>>n1;
    cout<<"INGRESAR NUMERO ";
    cin>>n2;
    cout<<"INGRESAR NUMERO ";
    cin>>n3;
    if(n1>n2 && n1>n3){
        cout<<"MAYOR ES "<<n1;
    }
    else{
        if(n2>n3){
            cout<<"EL MAYOR ES "<<n2;
        }
        else{
            cout<<"EL MAYOR ES "<<n3;
        }
    }
	cout<<endl;
	system("pause");
	return 0;
}
