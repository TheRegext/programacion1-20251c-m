///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;
///est� incompleto. Ver posibilidades

int main(){
    int n1, n2, n3;
    int resultado;
    cout<<"INGRESAR NUMERO ";
    cin>>n1;
    cout<<"INGRESAR NUMERO ";
    cin>>n2;
    cout<<"INGRESAR NUMERO ";
    cin>>n3;
    ///fin ingreso
    resultado=(n1<n2)+(n1<n3)+(n2<n3);
    cout<<resultado;



	cout<<endl;
	system("pause");
	return 0;
}
