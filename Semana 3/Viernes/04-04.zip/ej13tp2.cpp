///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;


int main(){
    int n1, n2, n3;
    int menor, medio, mayor;
    cout<<"INGRESAR NUMERO ";
    cin>>n1;
    cout<<"INGRESAR NUMERO ";
    cin>>n2;
    cout<<"INGRESAR NUMERO ";
    cin>>n3;
    ///fin ingreso
    if(n1<n2 && n1<n3){
        menor=n1;
        if(n2<n3){
            medio=n2;
            mayor=n3;
        }
        else{
           medio=n3;
           mayor=n2;
        }
    }
    else{
        ///sabemos que n1 no es menor
        if(n2<n3){
            menor=n2;
            if(n1<n3){
                medio=n1;
                mayor=n3;
            }
            else{
                medio=n3;
                mayor=n1;
            }
        }
        else{
            ///sabemos que n1 no es el menor y que tampoco lo es n2
            menor=n3;
            if(n1<n2){
                medio=n1;
                mayor=n2;
            }
            else{
                medio=n2;
                mayor=n1;
            }
        }
    }
    ///salida
    cout<<"NUMEROS ORDENADOS "<<menor<<", "<<medio<<", "<<mayor;
	cout<<endl;
	system("pause");
	return 0;
}
