///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;

///suponer que los valores son todos positivos

int main(){
    int n1, mayor=0;
    ///***
    cout<<"INGRESAR NUMERO ";
    cin>>n1;
    if(n1>mayor){
        mayor=n1;
    }
    ///***

    cout<<"INGRESAR NUMERO ";
    cin>>n1;
    if(n1>mayor){
        mayor=n1;
    }

    ///****
    cout<<"INGRESAR NUMERO ";
    cin>>n1;
    if(n1>mayor){
        mayor=n1;
    }

	///***
	cout<<"VALOR MAYOR O MAXIMO INGRESADO "<<mayor;
	cout<<endl;
	system("pause");
	return 0;
}
