///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;

///suponer que los valores son todos positivos
///for(valor inicial de la variable; condici�n a analizar; incremento)
///{
    ///instrucciones
///}

int main(){
    int n1, mayor=0;
    int k;
    /// k++ al valor de la variable se le suma 1 k=k+1
    for(k=10;k>5;k--){
        cout<<"Valor de la variable de control dentro del for ";
        cout<<k<<endl;
        k++;
    }
	cout<<endl;
    cout<<"Valor de la variable de control FUERA del for ";
    cout<<k<<endl;


	system("pause");
	return 0;
}
