///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;

///suponer que los valores son todos positivos
///for(valor inicial de la variable; condici�n a analizar; incremento)
///{
    ///instrucciones
///}

int main(){
    int n1, mayor=0;
    int k;
    /// k++ al valor de la variable se le suma 1 k=k+1
    for(k=1;k<=5;k++){
        cout<<"INGRESAR NUMERO ";
        cin>>n1;
        if(n1>mayor){
            mayor=n1;
        }
    }


	cout<<"VALOR MAYOR O MAXIMO INGRESADO "<<mayor;
	cout<<endl;
	system("pause");
	return 0;
}
