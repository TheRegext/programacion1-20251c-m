///Ejercicio:
///Autor:DEK
///Fecha:
///Comentario:

# include<iostream>


using namespace std;


int main(){

    int n1=0, n2, suma;///variables espacios de memoria donde los programas puedenleer y escribir
	///float numeroReal;
	///bool valor;
	///n2=n1=0;
	///n2 cu�nto tiene? 0, porque n1 tiene 0
	///cin>>n1;
	///cin>>n2;
	n1=1.9;
	n2=1.9;
	cout<<"n1 "<<n1<<endl;
	suma=n1+n2;
	cout<<suma;
	cout<<endl;
	system("pause");
	return 0;
}
